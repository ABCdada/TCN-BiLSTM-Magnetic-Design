Synthetic fine-tuning data-format example

Files:
- B.csv: 12 rows x 1000 flux-density values in tesla
- H.csv: 12 rows x 1000 synthetic field-strength values in A/m
- T.csv: one temperature in degrees Celsius per row
- acquisition_id.csv: one independent-record identifier per row

This ZIP is a deterministic format-only fixture. It contains no measured data,
does not reproduce a manuscript experiment, and is not accepted by a Web
fine-tuning endpoint in this inference-focused release. A future trainer must
split acquisition IDs before any overlapping window extraction.
